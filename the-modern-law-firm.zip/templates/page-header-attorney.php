<?php
$showTitle = getNormalizedMeta('show_page_title', true);
if( $showTitle ) { ?>
    <div class="page-header">
        <h1><?php
            echo roots_title();

            if (has_post_thumbnail()) {
                the_post_thumbnail(ATTORNEY_IMG_SM, array( 'class'	=> "attachment-post-thumbnail alignright ml20"));
            }
            ?>
        </h1>
    </div> <?php
} else { ?>
    <div class="buffer"></div> <?php
}

?>