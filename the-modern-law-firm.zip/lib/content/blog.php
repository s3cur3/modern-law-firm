<?php
add_action('init', 'set_blog_options');
function set_blog_options() {
    if ( function_exists( 'add_image_size' ) ) {
        add_image_size( FULL_WIDTH_WITH_SIDEBAR_IMG, 690, 9999 );
        add_image_size( THUMBNAIL_IMG, 275, 9999 );
    }
}