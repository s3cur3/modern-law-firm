<?php
define("SLIDE_TYPE", "modern-law-slide");
define("SIZE_LG", SLIDE_TYPE . '-fullscreen');
define("SIZE_MD", SLIDE_TYPE . '-contentwidth');


define("ATTORNEY_TYPE", "modern-law-attorney");
define("ATTORNEY_IMG", ATTORNEY_TYPE . '-photo');
define("ATTORNEY_IMG_SM", ATTORNEY_TYPE . '-thumbnail');

define("FULL_WIDTH_WITH_SIDEBAR_IMG", "modern-law-full-width");
define("THUMBNAIL_IMG", "modern-law-thumb");
