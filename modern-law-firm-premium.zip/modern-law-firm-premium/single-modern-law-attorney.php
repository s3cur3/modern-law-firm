<!-- SINGLE ATTORNEY -->
<?php get_template_part('templates/page', 'header-attorney'); ?>
<?php get_template_part('templates/content', 'attorney'); ?>
