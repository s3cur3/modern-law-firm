<?php
header('Content-Type: application/json');

require_once "../../../lib/appearance/googleFonts.php";

global $fontsJSON;
echo $fontsJSON;