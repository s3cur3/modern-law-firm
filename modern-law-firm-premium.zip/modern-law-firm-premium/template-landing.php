<?php
/*
Template Name: Landing page
*/
?>
<!-- template-landing.php -->
<?php get_template_part('templates/page', 'header'); ?>
<?php get_template_part('templates/content', 'page'); ?>
