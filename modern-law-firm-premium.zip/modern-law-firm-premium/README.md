Theme Name:         The Modern Law Firm
Theme URI:          http://conversioninsights.net/free-wordpress-themes-law-firms/modern-law-firm-premium/
Description:        A clean, modern, responsive theme just for lawyers & law firms.
Version:            6.5.1
Author:             Tyler Young
Author URI:         http://conversioninsights.net/tyler-young





For full documentation, open this theme's "docs" directory and open the "modern-law-firm-documentation.html" file.

